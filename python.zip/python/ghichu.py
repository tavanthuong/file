# =================Lấy mã Email OTP =================
async def request_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not authorized(update):
        return

    status, body = client.send_email_otp()

    if status == 200:
        await update.message.reply_text("✅ OTP đã gửi về email.\nDùng /verify mã otp")
    else:
        await update.message.reply_text(f"❌ Lỗi gửi OTP:\n{body}")


#Nhập mã OTP
async def verify_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global trading_token, account_no

    if not authorized(update):
        return

    if len(context.args) != 1:
        await update.message.reply_text("Sai cú pháp: /verify 123456")
        return

    otp_code = context.args[0]
    loop = asyncio.get_running_loop()


    # ===== TẠO TRADING TOKEN =====
    status, body = await loop.run_in_executor(
        None,
        lambda: client.create_trading_token(
            otp_type="smart_otp",
            passcode=otp_code,
            dry_run=False
        )
    )

    print("CREATE TOKEN RESPONSE:", status, body)

    if status != 200:
        await update.message.reply_text(f"❌ Lỗi tạo trading token:\n{body}")
        return

    # 🔥 Parse JSON nếu body là string
    if isinstance(body, str):
        try:
            body = json.loads(body)
        except:
            await update.message.reply_text("Lỗi parse tradingToken.")
            return

    trading_token = body.get("tradingToken")

    if not trading_token:
        await update.message.reply_text("Không nhận được tradingToken.")
        return

    # Gắn token vào client
    client.trading_token = trading_token

    # ===== LẤY DANH SÁCH TÀI KHOẢN =====
    acc_status, acc_body = await loop.run_in_executor(
       None,
       lambda: client.get_accounts(dry_run=False)
    )
    if acc_status != 200:
        await update.message.reply_text(f"Lỗi lấy tài khoản:\n{acc_body}")
        return

    if isinstance(acc_body, str):
        try:
            acc_body = json.loads(acc_body)
        except:
            await update.message.reply_text("Lỗi parse dữ liệu tài khoản.")
            return

    print("ACC BODY:", acc_body)

    if not isinstance(acc_body, dict):
        await update.message.reply_text("Dữ liệu tài khoản không hợp lệ.")
        return
    
    investor_name = acc_body.get("name", "Không rõ")
    accounts = acc_body.get("accounts", [])

    if not accounts:
        await update.message.reply_text("Không có tài khoản.")
        return

    account_no = accounts[0]["id"]

    if not account_no:
        await update.message.reply_text("Không lấy được số tài khoản.")
        return

    await update.message.reply_text(
        f"🎉 Xác thực thành công!\n\n"
        f"👤 Nhà đầu tư: {investor_name}\n"
        f"💳 Tài khoản: {account_no}"
)
    


    # ================= Kiểm tra xác thực =================
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global account_no

    if not authorized(update):
        return

    if account_no is None:
        await update.message.reply_text("⚠️ Chưa xác thực. Dùng /otp và /verify lấy mã trước.")
        return

    raw = update.message.text.strip()
    text = unidecode(raw).upper().split()

    if len(text) == 0:
        return