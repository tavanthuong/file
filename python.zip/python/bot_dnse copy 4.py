import json
import asyncio
import sys
import os
import subprocess
import time
import requests
import re
from unidecode import unidecode
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


from telegram import Update
from telegram.ext import (
    CallbackQueryHandler,
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

from telegram.request import HTTPXRequest
from dotenv import load_dotenv
from datetime import datetime
import pytz
import time




from dnse import DNSEClient
cancel_locks = {}

# ==================== CẤU HÌNH ====================



BOT_TOKEN_ENC = "token_telegram.enc"
API_KEY_ENC = "api_key.enc"
API_SECRET_ENC = "api_secret.enc"


# ================= Giải mã API =================

def decrypt_file(encrypted_file: str) -> str:
    """Giải mã file .enc bằng OpenSSL"""
    try:
        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-d", "-pbkdf2",
                "-in", encrypted_file,
                "-pass", f"file:api.key"
            ],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    

    except subprocess.CalledProcessError:
        print(f"❌ Lỗi giải mã {encrypted_file}")
        sys.exit(1)

    except FileNotFoundError:
        print("❌ Lỗi: OpenSSL chưa được cài đặt")
        sys.exit(1)

    
print("🔄 Đang giải mã thông tin...")

BOT_TOKEN = decrypt_file(BOT_TOKEN_ENC)
API_KEY = decrypt_file(API_KEY_ENC)
API_SECRET = decrypt_file(API_SECRET_ENC)
    
print("✅ Giải mã thành công!")
    

AUTHORIZED_CHAT_ID = 7274863226  # THAY BẰNG ID CỦA BẠN
BASE_URL = "https://openapi.dnse.com.vn"


# ================= DNSE CLIENT =================
client = DNSEClient(
    api_key=API_KEY,
    api_secret=API_SECRET,
    base_url=BASE_URL,
)

account_no = None
trading_token = None
current_otp_type = None

pending_orders = {}


# ================= GIỜ GIAO DỊCH VN =================
def is_trading_time():
    return True


async def safe_send(update, text):
    MAX_LEN = 4000
    for i in range(0, len(text), MAX_LEN):
        await update.message.reply_text(text[i:i+MAX_LEN])


# ================= HELPER =================
def authorized(update: Update):
    return update.effective_chat.id == AUTHORIZED_CHAT_ID

async def request_otp_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.args = ["email"]
    await request_otp(update, context)


async def request_otp_smart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.args = ["smart"]
    await request_otp(update, context)


# =================Lấy mã Email OTP hoặc Smart OTP =================
async def request_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global current_otp_type

    if not authorized(update):
        return

    if len(context.args) != 1:
        await update.message.reply_text(
            "Dùng:\n"
            "/otp_email  → nhận OTP qua email\n"
            "/otp_smart  → dùng Smart OTP trong app"
        )
        return

    otp_mode = context.args[0].lower()

    # ===== EMAIL OTP =====
    if otp_mode == "email":
        current_otp_type = "email_otp"

        loop = asyncio.get_running_loop()
        status, body = await loop.run_in_executor(
            None,
            lambda: client.send_email_otp(dry_run=False)
        )

        if status == 200:
            await update.message.reply_text(
                "📧 OTP đã gửi về email.\n"
                "Nhập: /verify 123456"
            )
        else:
            await update.message.reply_text(f"Lỗi gửi OTP:\nEmail OTP chưa đăng ký cho tài khoản\n")

    # ===== SMART OTP =====
    elif otp_mode == "smart":
        current_otp_type = "smart_otp"

        await update.message.reply_text(
            "🔐 Mở app DNSE → lấy Smart OTP\n"
            "Nhập: /verify 123456 (trong 30 giây)"
        )

    else:
        await update.message.reply_text("Lỗi gửi OTP: Smart OTP chưa đăng ký cho tài khoản\n")

      #====== Nhập mã OTP ======
async def verify_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global trading_token, account_no, current_otp_type

    if not authorized(update):
        return

    if not current_otp_type:
        await update.message.reply_text("Chưa chọn loại OTP. Dùng /otp email hoặc /otp smart")
        return

    if len(context.args) != 1:
        await update.message.reply_text("Sai cú pháp: /verify 123456")
        return

    otp_code = context.args[0]
    loop = asyncio.get_running_loop()

    status, body = await loop.run_in_executor(
        None,
        lambda: client.create_trading_token(
            otp_type=current_otp_type,
            passcode=otp_code,
            dry_run=False
        )
    )

    print("CREATE TOKEN RESPONSE:", status, body)

    if status != 200:
        await update.message.reply_text(f"Lỗi tạo trading token:\n{body}")
        return

    if isinstance(body, str):
        body = json.loads(body)

    trading_token = body.get("tradingToken")

    if not trading_token:
        await update.message.reply_text("Không nhận được tradingToken.")
        return

    client.trading_token = trading_token

    # ===== Lấy tài khoản =====
    acc_status, acc_body = await loop.run_in_executor(
        None,
        lambda: client.get_accounts(dry_run=False)
    )

    if acc_status != 200:
        await update.message.reply_text(f"Lỗi lấy tài khoản:\n{acc_body}")
        return

    if isinstance(acc_body, str):
        acc_body = json.loads(acc_body)

    investor_name = acc_body.get("name", "Không rõ")
    accounts = acc_body.get("accounts", [])

    if not accounts:
        await update.message.reply_text("Không có tài khoản.")
        return

    account_no = accounts[0]["id"]
    


    await update.message.reply_text(
        f"🎉 Xác thực thành công!\n\n"
        f"👤 Nhà đầu tư: {investor_name}\n"
        f"💳 Tài khoản: {account_no}\n"
        f"⏱️ Token hiệu lực 8 giờ\n"
    )

    # ================= Kiểm tra xác thực =================

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global account_no, trading_token, current_otp_type
    
    raw = update.message.text.strip()
    text_str = unidecode(raw).upper()
    tokens = text_str.split()



    # ===== AUTO VERIFY OTP nếu nhập 6 số =====
    if current_otp_type and raw.isdigit() and len(raw) == 6:

        otp_code = raw
        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.create_trading_token(
                otp_type=current_otp_type,
                passcode=otp_code,
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"❌ OTP sai:\n{body}")
            return

        if isinstance(body, str):
            body = json.loads(body)

        trading_token = body.get("tradingToken")
        client.trading_token = trading_token

        acc_status, acc_body = await loop.run_in_executor(
            None,
            lambda: client.get_accounts(dry_run=False)
        )

        if isinstance(acc_body, str):
            acc_body = json.loads(acc_body)

        investor_name = acc_body.get("name", "Không rõ")
        accounts = acc_body.get("accounts", [])

        if not accounts:
            await update.message.reply_text("Không có tài khoản.")
            return

        account_no = accounts[0]["id"]

        await update.message.reply_text(
            f"🎉 Xác thực thành công!\n\n"
            f"👤 Nhà đầu tư: {investor_name}\n"
            f"💳 Tài khoản: {account_no}\n"
            f"⏱️ Token hiệu lực 8 giờ"
        )

        return

    # ===== Sau khi đã xác thực =====
    if account_no is None:
        await update.message.reply_text("⚠️ Chưa xác thực. Dùng /otp_email hoặc /otp_smart")
        return

    text = unidecode(raw).upper().split()

    if len(text) == 0:
        return
    
    text_str = unidecode(raw).upper()
    tokens = text_str.split()


    # ===== Thông tin tiền =====
    if text_str.startswith(("TAI", "TAI SAN TIEN")):

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.get_balances(
                account_no=account_no,
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"Lỗi thông tin tiền:\n{body}")
            return
        
        
        if isinstance(body, str):
            body = json.loads(body)

        stock = body.get("stock", {})
        derivative = body.get("derivative", {})

        # ===== LẤY GIÁ TRỊ CỔ PHIẾU HIỆN TẠI =====
        status_d, body_d = await loop.run_in_executor(
            None,
            lambda: client.get_deals(
                account_no=account_no,
                market_type="STOCK",
                dry_run=False
            )
        )

        total_stock_value = 0

        if status_d == 200:
            if isinstance(body_d, str):
                body_d = json.loads(body_d)

            deals = body_d.get("deals", [])

            for d in deals:
                qty = d.get("openQuantity", 0)
                price = d.get("marketPrice", 0)
                total_stock_value += qty * price

            total_cash = stock.get("totalCash", 0)
            net_asset = total_cash + total_stock_value



        def fmt(value):
            return f"{value:,.0f}" if isinstance(value, (int, float)) else "0"

        msg = "💰 THÔNG TIN TIỀN\n\n"

        msg += "🏦 --- CƠ SỞ (STOCK) ---\n\n"

        msg += (
            f"🏦 Tài sản ròng (NAV): {fmt(net_asset)}\n"
            f"💵 Tổng tiền hiện có: {fmt(stock.get('totalCash',0))}\n"
            f"💰 Tiền mặt khả dụng: {fmt(stock.get('availableCash',0))}\n"
            f"📤 Số tiền có thể rút: {fmt(stock.get('withdrawableCash',0))}\n"
            f"📊 Giá trị cổ phiếu hiện tại: {fmt(total_stock_value)}\n"
            f"🏦 Tổng nợ: {fmt(stock.get('totalDebt',0))}\n"
            f"💳 Phí lưu ký: {fmt(stock.get('depositFeeAmount',0))}\n"
            f"📈 Lãi tiền gửi: {fmt(stock.get('depositInterest',0))}\n"
 #           f"💳 Nợ margin: {fmt(stock.get('marginDebt',0))}\n"
 #           f"⏳ Tiền chờ về: {fmt(stock.get('receivingAmount',0))}\n"
 #          f"🔒 Tiền mua khớp trong ngày: {fmt(stock.get('secureAmount',0))}\n"
            f"🎁 Cổ tức chờ về: {fmt(stock.get('cashDividendReceiving',0))}\n"
        )

        #msg += "\n📈 --- PHÁI SINH (DERIVATIVE) ---\n\n"

      #  msg += (
       #     f"💰 Ký quỹ còn lại: {fmt(derivative.get('remainSecure',0))}\n"
        #    f"📌 Ký quỹ đã sử dụng: {fmt(derivative.get('usedSecure',0))}\n"
         #   f"⏳ Ký quỹ chờ xử lý: {fmt(derivative.get('pendingSecure',0))}\n"
          #  f"💵 Thuế & phí giữ lại: {fmt(derivative.get('holdTaxAndFee',0))}\n"
          #  f"💳 Tổng nợ vay: {fmt(derivative.get('totalLoanDebt',0))}\n"
            #f"🔄 Nạp/rút chờ xử lý: {fmt(derivative.get('pendingDepositWithdraw',0))}\n"
       # )

        await update.message.reply_text(msg)
        return

    
     # ===== DANH MỤC / GÕ TRỰC TIẾP MÃ =====

    raw = update.message.text.strip()
    text_raw = raw.split()
    text = unidecode(raw).upper().split()


    #if text[0] in ["DANH", "DANHMUC", "DANH MUC"] or (
     #   len(text) == 1 and text[0].isalpha()
    #):
    if text[0] in ["DANH", "DANHMUC", "DANH MUC"]:


    # ===== LẤY DANH SÁCH DEAL =====
        status, body = client.get_deals(
            account_no=account_no,
            market_type="STOCK",
            dry_run=False
        )

        if status != 200:
            await update.message.reply_text("❌ Lỗi lấy danh mục.")
            return

        if isinstance(body, str):
            body = json.loads(body)

        deals = body.get("deals", [])

        if not deals:
            await update.message.reply_text("📊 Danh mục trống.")
            return

    # ===== XÁC ĐỊNH CÓ LỌC MÃ KHÔNG =====
        filter_symbol = None

    # Trường hợp: DANH MUC HSG
        if len(text) >= 3:
            filter_symbol = text[2].upper()

    # Trường hợp: HSG (gõ trực tiếp)
        elif len(text) == 1 and text[0] not in ["DANH"]:
            filter_symbol = text[0].upper()

        msg = "📊 DANH MỤC NẮM GIỮ\n\n"
        found = False

        total_initial_value = 0
        total_current_value = 0
        total_profit = 0

        for s in deals:
            if not isinstance(s, dict):
                continue

            symbol = s.get("symbol", "").upper()
            quantity = s.get("openQuantity", 0)

        # Bỏ qua nếu không còn nắm giữ
            if quantity <= 0:
                continue

            if filter_symbol and symbol != filter_symbol:
                continue

            found = True

            break_price = float(s.get("breakEvenPrice", 0))
            market_price = float(s.get("marketPrice", 0))
            
            break_price_int = int(round(break_price))
            initial_value = break_price_int * quantity
            current_value = market_price * quantity


            market_price_int = int(round(market_price))
            profit = (market_price_int - break_price_int) * quantity

            total_initial_value += initial_value
            total_current_value += current_value
            total_profit += profit



            percent = 0
            if break_price > 0:
                percent = ((market_price - break_price) / break_price) * 100


            msg += (
                f"Mã: {symbol}\n"
                f"KL: {quantity}\n"
                f"Giá vốn: {break_price:,.0f}\n"
                f"Giá hiện tại: {market_price:,.0f}\n"
                f"💰 Giá trị ban đầu: {initial_value:,.0f}\n"
                f"💵 Giá trị hiện tại: {current_value:,.0f}\n"
                f"📈 Lãi/Lỗ tạm tính: {profit:,.0f} ({percent:+.2f}%)\n"
                f"----------------------\n"
            )


        if not found:
            await update.message.reply_text("Không có cổ phiếu nào.")
            return
        
        # ===== HIỂN THỊ TỔNG CHỈ KHI KHÔNG LỌC MÃ =====
        if not filter_symbol:

            total_percent = 0
            if total_initial_value > 0:
                total_percent = (total_profit / total_initial_value) * 100

            msg += (
                "========================\n"
                f"🧾 Tổng vốn: {total_initial_value:,.0f}\n"
                f"📊 Giá trị thị trường: {total_current_value:,.0f}\n"
                f"📈 Lãi/Lỗ danh mục: {total_profit:,.0f} ({total_percent:+.2f}%)\n"
            )



        await safe_send(update, msg)
        return
    
    

    raw = update.message.text.strip()
    text = unidecode(raw).upper().split()

       # ===== GÓI VAY / MARGIN =====
    if len(text) >= 2 and text[0] in ["GOI", "MARGIN"]:

        symbol = text[-1]   # lấy từ cuối cùng (HPG)

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.get_loan_packages(
                account_no=account_no,
                market_type="STOCK",
                symbol=symbol,
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"❌ Lỗi lấy gói vay:\n{body}")
            return

        if isinstance(body, str):
            body = json.loads(body)

        packages = body.get("loanPackages", [])

        if not packages:
            await update.message.reply_text(f"Không có gói vay cho {symbol}.")
            return

        msg = f"📦 GÓI VAY MARGIN {symbol.upper()}\n\n"

        for p in packages:

            loan_id = p.get("id")
            name = p.get("name", "").strip()

            initial_rate = p.get("initialRate", 0)  # ví dụ 0.5
            interest_rate = p.get("interestRate", 0)  # ví dụ 0.0999

            # Tỷ lệ vay = 1 - initialRate
            loan_rate = (1 - initial_rate) * 100

            msg += f"ID: {loan_id}\n"
            msg += f"Tên: {name}\n"
            msg += f"----------\n"
         # Nếu là gói margin (initialRate < 1)
        if initial_rate < 1:
            msg += f"Tỷ lệ vay: {loan_rate:.0f}%\n"
            msg += f"Lãi suất: {interest_rate*100:.2f}%\n"

        msg += "\n"


        await update.message.reply_text(msg)
        return

         # ===== SỔ LỆNH =====
    if text[:2] == ["SO", "LENH"]:

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.get_orders(
                account_no=account_no,
                market_type="STOCK",
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"Lỗi lấy sổ lệnh:\n{body}")
            return

        if isinstance(body, str):
            body = json.loads(body)

        orders = body.get("orders", [])

        if not orders:
            await update.message.reply_text("📒 Không có lệnh nào.")
            return

        # Lọc theo mã nếu có
        filter_symbol = None
        if len(text) == 3:
            filter_symbol = text[2].upper()

        from datetime import datetime, timedelta

        msg = "📒 SỔ LỆNH\n\n"
        total_order_value = 0
        found = False

        for o in orders:

            if not isinstance(o, dict):
                continue

            symbol = o.get("symbol", "").upper()

            if filter_symbol and symbol != filter_symbol:
                continue

            found = True

            side = o.get("side", "")
            if side == "NB":
                 side_text = "🟢 Lệnh mua"
            elif side == "NS":
                side_text = "🔴 Lệnh bán"
            else:
                side_text = f"❓ {side}"

            status_map = {
                "Pending": "🟡 Lệnh được tạo",
                "PendingNew": "🟡 Chờ gửi",
                "New": "🟠 Chờ khớp",
                "PartiallyFilled": "🟡 Khớp một phần",
                "Filled": "🟢 Khớp toàn bộ",
                "Rejected": "🔴 Bị từ chối",
                "Canceled": "⚫ Đã hủy",
                "Expired": "⏳ Hết hạn trong phiên",
                "PendingCancel": "⏳ Lệnh chờ hủy",
                "PendingReplace": "🟣 Lệnh chờ sửa",
                "DoneForDay": "🔵 Lệnh được giải tỏa"
            }

            status_text = status_map.get(o.get("orderStatus"), o.get("orderStatus"))

            price = o.get("price", 0)
            quantity = o.get("quantity", 0)
            order_value = price * quantity
            total_order_value += order_value

            # ===== Giờ VN =====
            created_time = o.get("createdDate")
            if created_time:
                try:
                    dt = datetime.strptime(created_time.split(".")[0], "%Y-%m-%dT%H:%M:%S")
                    dt_vn = dt + timedelta(hours=7)
                    time_part = dt_vn.strftime("%H:%M:%S")
                except:
                    time_part = "Không rõ"
            else:
                time_part = "Không rõ"

            msg += (
                f"{side_text}\n"
                f"🆔 ID: {o.get('id')}\n"
                f"📌 Mã: {symbol}\n"
                f"📍 Trạng thái: {status_text}\n"
                f"💰 Giá đặt: {price:,.0f}\n"
                f"📦 KL đặt: {quantity}\n"
                f"✅ KL khớp: {o.get('fillQuantity',0)}\n"
                f"❌ KL hủy: {o.get('canceledQuantity',0)}\n"
                f"📌 KL còn lại: {o.get('leaveQuantity',0)}\n"
                f"💵 Giá trị lệnh: {order_value:,.0f}\n"
                f"⏰ Thời gian: {time_part}\n"
                f"--------------------------\n"
            )

        if not found:
            await update.message.reply_text("Không tìm thấy mã trong sổ lệnh.")
            return

        await safe_send(update, msg)
        return


    # ================= CHI TIẾT LỆNH =================
    if (
        text[0] == "CHI"
        or raw.lower().startswith("chi tiet")
    ):

        filter_symbol = None

        clean_text = unidecode(raw).upper()
        parts = clean_text.split()

        if len(parts) >= 3:
            # Nếu cuối cùng là mã cổ phiếu
            last_word = parts[-1]
            if last_word not in ["CHI", "TIET", "LENH"]:
                filter_symbol = last_word

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.get_orders(
                account_no=account_no,
                market_type="STOCK",
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text("❌ Lỗi lấy dữ liệu.")
            return

        if isinstance(body, str):
            body = json.loads(body)

        orders = body.get("orders", [])

        if not orders:
            await update.message.reply_text("Không có chi tiết lệnh nào.")
            return

        msg = "📑 CHI TIẾT LỆNH\n\n"
        found = False

        for o in orders:

            symbol = o.get("symbol", "").upper()

            if filter_symbol and symbol != filter_symbol:
                continue

            found = True

            side = o.get("side", "")
            if side == "NB":
                 side_text = "🟢 Lệnh mua"
            elif side == "NS":
                side_text = "🔴 Lệnh bán"
            else:
                side_text = f"❓ {side}"


            price = o.get("price", 0)
            quantity = o.get("quantity", 0)
            value = price * quantity

            created_time = o.get("createdDate", "")
            time_only = ""
            if "T" in created_time:
                time_only = created_time.split("T")[1][:8]

            status_raw = o.get("orderStatus", "")

            status_map = {
                "Pending": "🟡 Lệnh được tạo",
                "PendingNew": "🟡 Chờ gửi",
                "New": "🟠 Chờ khớp",
                "PartiallyFilled": "🟡 Khớp một phần",
                "Filled": "🟢 Khớp toàn bộ",
                "Rejected": "🔴 Bị từ chối",
                "Canceled": "⚫ Đã hủy",
                "Expired": "⏳ Hết hạn trong phiên",
                "PendingCancel": "⏳ Lệnh chờ hủy",
                "PendingReplace": "🟣 Lệnh chờ sửa",
                "DoneForDay": "🔵 Lệnh được giải tỏa"
            }

            status_text = status_map.get(status_raw, status_raw)


            msg += (
                f"🆔 ID: {o.get('id')}\n"
                f"{side_text}\n"
                f"📌 Mã: {symbol}\n"
                f"🏦 Tài khoản: {o.get('accountNo')}\n"
                f"📄 Loại lệnh: {o.get('orderType')}\n"
                f"📊 Trạng thái: {status_text}\n"
                f"\n"
                f"💰 Giá đặt: {o.get('price', 0):,.0f}\n"
                f"🔒 Giá Secure: {o.get('priceSecure', 0):,.0f}\n"
                f"📦 KL đặt: {o.get('quantity', 0)}\n"
                f"📈 KL khớp: {o.get('fillQuantity', 0)}\n"
                f"📉 KL hủy: {o.get('canceledQuantity', 0)}\n"
                f"📊 KL còn lại: {o.get('leaveQuantity', 0)}\n"
                f"\n"
                f"📊 Giá khớp TB: {o.get('averagePrice', 0):,.0f}\n"
                f"📌 KL khớp gần nhất: {o.get('lastQuantity', 0)}\n"
                f"📌 Giá khớp gần nhất: {o.get('lastPrice', 0):,.0f}\n"
                f"\n"
                f"💵 Giá trị lệnh: {(o.get('price', 0) * o.get('quantity', 0)):,.0f}\n"
                f"💲 Thuế: {o.get('taxRate', 0)}\n"
                f"🏛 Phí sàn: {o.get('exchangeFeeRate', 0)}\n"
                f"💰 Phí giao dịch: {o.get('feeRate', 0)}\n"
                f"\n"
                f"📆 Ngày GD: {o.get('transDate')}\n"
                f"⏰ Giờ tạo: {o.get('createdDate', '').split('T')[1][:8] if 'T' in o.get('createdDate','') else ''}\n"
                f"⏰ Giờ sửa: {o.get('modifiedDate', '').split('T')[1][:8] if 'T' in o.get('modifiedDate','') else ''}\n"
                f"\n"
                f"🏦 LoanPackageID: {o.get('loanPackageId')}\n"
                f"⚠️ Lỗi: {o.get('error')}\n"
                f"📝 Metadata: {o.get('metadata')}\n"
                f"----------------------\n"
            )

        if not found:
            await update.message.reply_text("Không có lệnh nào.")
            return

        await safe_send(update, msg)
        return
    
    
    # =========================
    # Lệnh MUA / BÁN
    # =========================
    if tokens and tokens[0] in ["MUA", "BUY", "BAN", "SELL"]:

        side = "NB" if tokens[0] in ["MUA", "BUY"] else "NS"
        loop = asyncio.get_running_loop()

        # =========================
        # XÁC ĐỊNH BÁN HẾT
        # =========================
        sell_all = "HET" in tokens

        # =========================
        # LẤY SYMBOL
        # =========================
        # =========================
        # LẤY SYMBOL (LUÔN LẤY TOKEN THỨ 2)
        # =========================
        if len(tokens) < 2:
            await update.message.reply_text("❌ Thiếu mã chứng khoán.")
            return

        symbol = tokens[1]

        if not re.match(r"^[A-Z0-9]{2,15}$", symbol):
            await update.message.reply_text("❌ Mã chứng khoán không hợp lệ.")
            return


        if not symbol:
            await update.message.reply_text("❌ Không tìm thấy mã cổ phiếu.")
            return
        
        # =========================
        # LẤY PHẦN SAU SYMBOL
        # =========================
        after_symbol = text_str.split(symbol, 1)[-1].strip()
        numbers = re.findall(r"\d+\.?\d*", after_symbol)

        price = None
        quantity = None

        # =========================
        # LỆNH THỊ TRƯỜNG
        # =========================
        market_order = "MTL" in tokens or "MOI GIA" in text_str

        if market_order:
            order_type = "MTL"
            price = 0
        else:
            order_type = "LO"

        # =========================
        # XÁC ĐỊNH GIÁ + KHỐI LƯỢNG
        # =========================
        if not sell_all:

            if len(numbers) >= 2:

                raw_price = numbers[0]
                raw_qty = numbers[1]

                # Giá có dấu chấm → nhân 1000
                if "." in raw_price:
                    price = int(float(raw_price) * 1000)
                else:
                    price = int(raw_price)

                quantity = int(raw_qty)

            else:
                await update.message.reply_text("❌ Sai cú pháp. Ví dụ: MUA HPG 25.5 1000")
                return

        # =========================
        # BÁN HẾT → LẤY OPEN QUANTITY
        # =========================
        if side == "NS" and sell_all:

            status_d, body_d = await loop.run_in_executor(
                None,
                lambda: client.get_deals(
                    account_no=account_no,
                    market_type="STOCK",
                    dry_run=False
                )
            )

            if isinstance(body_d, str):
                body_d = json.loads(body_d)

            deals = body_d.get("deals", [])

            quantity = sum(
                d.get("openQuantity", 0)
                for d in deals
                if d.get("symbol") == symbol
            )

            if quantity == 0:
                await update.message.reply_text("❌ Không có cổ phiếu để bán.")
                return

        if not quantity:
            await update.message.reply_text("❌ Không xác định được khối lượng.")
            return

        # =========================
        # LẤY GÓI VAY
        # =========================
        status_lp, body_lp = await loop.run_in_executor(
            None,
            lambda: client.get_loan_packages(
                account_no=account_no,
                market_type="STOCK",
                symbol=symbol,
                dry_run=False
            )
        )

        if isinstance(body_lp, str):
            body_lp = json.loads(body_lp)

        packages = body_lp.get("loanPackages", [])

        if not packages:
            await update.message.reply_text("❌ Không có gói vay.")
            return

        loan_id = packages[0]["id"]

        # =========================
        # TẠO PAYLOAD
        # =========================
        payload = {
            "accountNo": account_no,
            "symbol": symbol,
            "side": side,
            "orderType": order_type,
            "price": price,
            "quantity": quantity,
            "loanPackageId": loan_id
        }

        # ====== XÁC NHẬN 2 BƯỚC ======
        user_id = update.effective_user.id
        if "pending_orders" not in context.bot_data:
            context.bot_data["pending_orders"] = {}



        context.bot_data["pending_orders"][user_id] = payload

        side_text = "🟢 MUA" if side == "NB" else "🔴 BÁN"

        value = price * quantity if price else 0

        # Lấy tiền khả dụng để tính %
        status_b, body_b = await loop.run_in_executor(
            None,
            lambda: client.get_balances(
                account_no=account_no,
                dry_run=False
            )
        )

        available_cash = 0
        if status_b == 200:
            if isinstance(body_b, str):
                body_b = json.loads(body_b)
            stock_info = body_b.get("stock", {})
            available_cash = stock_info.get("availableCash", 0)

        cash_percent = 0
        if available_cash > 0:
            cash_percent = (value / available_cash) * 100

            # =========================
            # KIỂM TRA ĐỦ TIỀN
            # =========================
        if side == "NB" and value > available_cash:
            await update.message.reply_text(
                f"❌ Không đủ tiền khả dụng.\n\n"
                f"💵 Tiền khả dụng: {available_cash:,.0f}\n"
                f"💎 Giá trị lệnh: {value:,.0f}"
            )
            return


        value = price * quantity if price else 0

        keyboard = [
            [
                InlineKeyboardButton("❌ HỦY", callback_data="cancel_order"),
                InlineKeyboardButton("✅ XÁC NHẬN", callback_data="confirm_order"),
            ]
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)


        display_price = f"{price/1000:,.2f}" if price else "0"
        value = price * quantity if price else 0
        side_icon = "🟢" if side == "NB" else "🔴"
        side_text = "LỆNH MUA" if side == "NB" else "LỆNH BÁN"

        confirm_text = (
            f"{symbol} · HOSE\n\n"
            f"{side_icon} {side_text}\n\n"
            f"💰 Giá đặt:        {display_price}\n"
            f"📦 Khối lượng:     {quantity:,}\n"
            f"💵 Tiền mặt:       100%\n"
            f"💎 Giá trị lệnh:   {value:,}\n"
        )

        keyboard = [
            [
                InlineKeyboardButton("HỦY", callback_data="cancel_order"),
                InlineKeyboardButton("XÁC NHẬN", callback_data="confirm_order")
            ]
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(
            confirm_text,
            reply_markup=reply_markup
        )

        return
    



    
        # ===== HỦY LỆNH LINH HOẠT =====

    if text_str.lower().startswith(("huy", "hủy")):

        loop = asyncio.get_running_loop()
        cmd = text_str.lower()

        # ===== LẤY SỔ LỆNH =====
        status_o, body_o = await loop.run_in_executor(
            None,
            lambda: client.get_orders(
                account_no=account_no,
                market_type="STOCK",
                dry_run=False
            )
        )

        if status_o != 200:
            await update.message.reply_text("❌ Không lấy được sổ lệnh.")
            return

        if isinstance(body_o, str):
           body_o = json.loads(body_o)

        orders = body_o.get("orders", [])

        # Chỉ lấy lệnh chưa khớp hết
        pending_orders = [
            o for o in orders
            if o.get("leaveQuantity", 0) > 0
        ]

        if not pending_orders:
            await update.message.reply_text("✅ Không có lệnh chờ.")
            return

        tokens = cmd.split()

        # ===== TRƯỜNG HỢP: HUY 123 =====
        if len(tokens) == 2 and tokens[1].isdigit():
            order_ids = [int(tokens[1])]

        # ===== TRƯỜNG HỢP: HUY TẤT CẢ =====
        elif "tat" in cmd or "tất" in cmd:
            order_ids = [o["id"] for o in pending_orders]

        # ===== TRƯỜNG HỢP: HUY HPG =====
        elif len(tokens) >= 2:
            symbol = tokens[-1].upper()

            matched = [
                o for o in pending_orders
                if o.get("symbol", "").upper() == symbol
            ]

            if not matched:
                await update.message.reply_text(f"❌ Không có lệnh chờ {symbol}.")
                return

            order_ids = [o["id"] for o in matched]

        else:
            await update.message.reply_text(
                "📌 Cách hủy lệnh:\n"
                "• HUY 123\n"
                "• HUY HPG\n"
                "• HỦY LỆNH SSI\n"
                "• HỦY LỆNH TẤT CẢ"
            )
            return

         # ===== TIẾN HÀNH HỦY =====
        result_msg = "🛑 KẾT QUẢ HỦY LỆNH\n\n"

        for oid in order_ids:
            status_c, body_c = await loop.run_in_executor(
                None,
                lambda oid=oid: client.cancel_order(
                    account_no=account_no,
                    market_type="STOCK",
                    order_id=oid,
                    trading_token=trading_token,
                    order_category="NORMAL",
                    dry_run=False,
                )
            )

            if status_c == 200:
                result_msg += f"✅ Đã hủy lệnh ID {oid}\n"
            else:
                result_msg += f"❌ Hủy lỗi ID {oid}\n"

        await safe_send(update, result_msg)
        return
    
    await update.message.reply_text("Không hiểu lệnh.")



async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global trading_token

    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    pending_orders = context.bot_data.get("pending_orders", {})
    pending = pending_orders.get(user_id)

    if query.data == "cancel_order":
        pending_orders.pop(user_id, None)
        await query.edit_message_text("❌ Đã hủy đặt lệnh.")
        return

    if query.data == "confirm_order":

        if not pending:
            await query.edit_message_text("⚠️ Không có lệnh chờ.")
            return

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.post_order(
                market_type="STOCK",
                payload={
                "accountNo": account_no,
                "symbol": pending["symbol"],
                "side": pending["side"],
                "orderType": pending["orderType"],
                "price": pending["price"],
                "quantity": pending["quantity"],
                "loanPackageId": pending["loanPackageId"],
            },
            trading_token=trading_token,
            order_category="NORMAL",
            dry_run=False,
        )

        )

        pending_orders.pop(user_id, None)

        if status == 200:

            if isinstance(body, str):
                body = json.loads(body)

            order_id = body.get("id", "N/A")

            side_text = "🟢 MUA" if pending["side"] == "NB" else "🔴 BÁN"
            symbol = pending["symbol"]
            quantity = pending["quantity"]
            price = pending["price"]
            value = price * quantity if price else 0

            await query.edit_message_text(
                f"✅ ĐẶT LỆNH THÀNH CÔNG\n\n"
                f"{side_text}: {symbol}\n"
                f"📦 Khối lượng: {quantity:,}\n"
                f"💰 Giá: {price:,}\n"
                f"💵 Giá trị: {value:,}\n"
                f"🆔 ID: {order_id}"
            )

            
        else:
            await query.edit_message_text(f"❌ Lỗi: {body}")
    
    
    

# ================= THEO DÕI KHỚP LỆNH =================
async def watch_filled_orders(application):
    print("👀 Watcher 24/7 đã chạy")

    last_status = {}
    first_run = False


    while True:
        try:
            loop = asyncio.get_running_loop()

            status, body = await loop.run_in_executor(
                None,
                lambda: client.get_orders(
                    account_no=account_no,
                    market_type="STOCK",
                    dry_run=False
                )
            )

            if isinstance(body, str):
                body = json.loads(body)

            orders = body.get("orders", [])

            for o in orders:
                order_id = o.get("id")
                symbol = o.get("symbol")
                side = o.get("side")

                

                fill_qty = o.get("fillQuantity", 0)
                quantity = o.get("quantity", 0)
                status_text = (o.get("orderStatus") or "").upper()

                

                prev_status = last_status.get(order_id)

                if first_run:
                    # Lần chạy đầu tiên chỉ ghi trạng thái, không gửi tin
                    last_status[order_id] = status_text
                    continue

                if prev_status == status_text:
                    continue


                icon = "🟢" if side == "NB" else "🔴"
                msg = None

                # ===== LỆNH CHỜ =====
                if status_text in ["NEW", "PENDINGNEW", "PENDING"]:
                    msg = f"⏳ Lệnh chờ gửi\n{icon} {symbol}\nKL: {quantity:,}"

                # ===== ĐANG HỦY =====
                elif status_text == "PENDINGCANCEL":
                    msg = f"⌛ Đang hủy lệnh\n{icon} {symbol}"

                # ===== HỦY THÀNH CÔNG =====
                elif status_text == "CANCELED":
                    msg = f"❌ Lệnh đã hủy\n{icon} {symbol}"

                # ===== KHỚP TOÀN BỘ =====
                elif status_text == "FILLED":
                    msg = f"🎯 Khớp toàn bộ\n{icon} {symbol}\nKL: {quantity:,}"

                # ===== KHỚP MỘT PHẦN =====
                elif status_text == "PARTIALLYFILLED":
                    msg = (
                        f"⚡ Khớp một phần\n"
                        f"{icon} {symbol}\n"
                        f"Đã khớp: {fill_qty:,}/{quantity:,}"
                    )

                if msg:
                    await application.bot.send_message(
                        chat_id=AUTHORIZED_CHAT_ID,
                        text=msg
                    )

                last_status[order_id] = status_text

            await asyncio.sleep(3)

        except Exception as e:
            print("❌ Lỗi watcher:", e)
            print(order_id, status_text)
            first_run = False
            await asyncio.sleep(5)







# ================= RUN BOT =================
request = HTTPXRequest(
    connect_timeout=30,
    read_timeout=30,
    write_timeout=30,
    pool_timeout=30,
)



print("🤖 Đang khởi động bot...")

async def post_init(application):
    application.create_task(watch_filled_orders(application))
    print("👀 Watcher đã khởi động")

app = (
    ApplicationBuilder()
    .token(BOT_TOKEN)
    .request(request)
    .post_init(post_init)
    .build()
)



app.add_handler(CommandHandler("otp", request_otp))
app.add_handler(CommandHandler("otp_email", request_otp_email))
app.add_handler(CommandHandler("otp_smart", request_otp_smart))
app.add_handler(CommandHandler("verify", verify_otp))

app.add_handler(CallbackQueryHandler(button_handler))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))



print("✅ Bot đã sẵn sàng! Đang chạy...")

    
app.run_polling(
        poll_interval=0.5,
        timeout=30,
        drop_pending_updates=True
)




