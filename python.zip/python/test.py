import json
import asyncio
import os
import subprocess
import time
from unidecode import unidecode
from dotenv import load_dotenv
from dnse import DNSEClient

# ================= Giải mã API =================
def decrypt(file):
    return subprocess.check_output(
        f"openssl enc -aes-256-cbc -d -pbkdf2 -in {file} -pass file:api.key",
        shell=True
    ).decode().strip()

BOT_TOKEN = decrypt("api_token_telegram.enc")
API_KEY = decrypt("api_key.enc")
API_SECRET = decrypt("api_secret.enc")
AUTHORIZED_CHAT_ID = 7274863226
BASE_URL = "https://openapi.dnse.com.vn"


# ================= DNSE CLIENT =================
client = DNSEClient(
    api_key=API_KEY,
    api_secret=API_SECRET,
    base_url=BASE_URL,
)


await update.message.reply_text(
            f"⚠️ XÁC NHẬN ĐẶT LỆNH\n\n"
            f"{side_text}: {symbol}\n"
            f"📦 KL: {quantity:,}\n"
            f"💰 Giá: {price:,}\n"
            f"💵 Giá trị: {value:,}\n\n"
            f"Gõ: OK để thực hiện\n"
            f"Gõ: NO để hủy lệnh\n"

        )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):

    raw = update.message.text.strip()
    text_str = unidecode(raw).upper()
    tokens = text_str.split()

    # =============================
       #XỬ LÝ XÁC NHẬN / HỦY LỆNH MUA BÁN
       # =============================

    user_id = update.effective_user.id
    pending_orders = context.bot_data.get("pending_orders", {})

        # --- XÁC NHẬN ---
    if text_str in ["OK", "XAC NHAN"]:

        if user_id not in pending_orders:
            await update.message.reply_text("❌ Không có lệnh chờ xác nhận.")
            return

        payload = pending_orders[user_id]

        status, body = await asyncio.get_running_loop().run_in_executor(
            None,
            lambda: client.post_order(
                market_type="STOCK",
                payload=payload,
                trading_token=trading_token,
                order_category="NORMAL",
                dry_run=False
            )
        )

        if isinstance(body, str):
            body = json.loads(body)

        if status == 200:

            order_id = body.get("id")
            side = payload["side"]
            symbol = payload["symbol"]
            price = payload["price"]
            quantity = payload["quantity"]
            side_text = "🟢 MUA" if side == "NB" else "🔴 BÁN"
            value = price * quantity if price else 0

            await update.message.reply_text(
                f"✅ ĐẶT LỆNH THÀNH CÔNG\n\n"
                f"{side_text}: {symbol}\n"
                f"📦 Khối lượng: {quantity:,}\n"
                f"💰 Giá: {price:,}\n"
                f"💵 Giá trị: {value:,}\n"
                f"🆔 ID: {order_id}"
            )

            # XÓA LỆNH CHỜ
            del context.bot_data["pending_orders"][user_id]

        else:

            error_code = body.get("code", "")
            error_msg = body.get("message", "")

            if error_code == "PRICE_MUST_LESS_THAN_OR_EQUAL_TO_CEILING_PRICE":
                await update.message.reply_text(
                "❌ Giá đặt vượt giá trần hôm nay.\n"
                "👉 Vui lòng kiểm tra lại giá."
                )

            elif error_code == "PRICE_MUST_GREATER_THAN_OR_EQUAL_TO_FLOOR_PRICE":
                await update.message.reply_text(
                    "❌ Giá đặt thấp hơn giá sàn hôm nay.\n"
                    "👉 Vui lòng kiểm tra lại giá."
                )

            else:
                await update.message.reply_text(
                    f"❌ Lỗi đặt lệnh:\n{error_msg}"
                )

        return


         # --- HỦY XÁC NHẬN ---
    if text_str in ["NO", "KO", "CANCEL"]:

        if user_id not in pending_orders:
            await update.message.reply_text("❌ Không có lệnh chờ hủy")
            return

        del context.bot_data["pending_orders"][user_id]

        await update.message.reply_text("🛑 ĐÃ HỦY LỆNH ")

        return
