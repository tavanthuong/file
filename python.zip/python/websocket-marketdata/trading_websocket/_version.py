"""Version information for trading_websocket package."""

__version__ = "1.0.0"
