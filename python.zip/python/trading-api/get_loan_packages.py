#!/usr/bin/env python3
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from dnse import DNSEClient
import json
import asyncio
import time
import subprocess
# ================= Giải mã API =================
def decrypt(file):
    return subprocess.check_output(
        f"openssl enc -aes-256-cbc -d -pbkdf2 -in {file} -pass file:api.key",
        shell=True
    ).decode().strip()

API_KEY = decrypt("api_key.enc")
API_SECRET = decrypt("api_secret.enc")
BASE_URL = "https://openapi.dnse.com.vn"

# ================= DNSE CLIENT =================
client = DNSEClient(
    api_key=API_KEY,
    api_secret=API_SECRET,
    base_url=BASE_URL,
)




status, body = client.get_loan_packages(
        account_no="0001250364",
        market_type="STOCK",
        symbol="ctg",
        dry_run=False,
    )
print(status, body)


if __name__ == "__main__":
    main()
