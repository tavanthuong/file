import requests

# ===== CẤU HÌNH ZALO BOT PLATFORM =====
BOT_TOKEN = "1349250043580692661:hXofYukONTGBNeoGrxOOUjlUGZKdcWwatDsvvGyNPwAbBNYZHyLyKBxpETUOFFwz"
ZALO_CHAT_ID = "fa6ecd98b2cc5b9202dd"


def send_zalo_message(text: str):
    try:
        url = f"https://bot-api.zaloplatforms.com/bot{BOT_TOKEN}/sendMessage"

        payload = {
            "chat_id": ZALO_CHAT_ID,
            "text": text
        }

        res = requests.post(url, json=payload, timeout=10)

        if res.status_code != 200:
            print("❌ Zalo send failed:", res.text)
        else:
            data = res.json()
            if not data.get("ok", True):
                print("❌ Zalo API error:", data)

    except Exception as e:
        print("❌ Lỗi gửi Zalo:", e)
