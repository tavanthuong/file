#!/usr/bin/env python3
"""
Telegram Bot cho DNSE Trading - Dùng SDK chính thức
Chỉ import từ dnse import DNSEClient
"""

import os
import json
import asyncio
import logging
import getpass
import subprocess
from typing import Dict, Any, Optional, Tuple

# Thư viện Telegram
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        Application, CommandHandler, MessageHandler, 
        CallbackQueryHandler, ContextTypes, filters
    )
    from unidecode import unidecode
except ImportError as e:
    print("=" * 60)
    print("❌ LỖI: Thiếu thư viện. Vui lòng cài đặt:")
    print("pip install python-telegram-bot unidecode")
    print("=" * 60)
    raise e

# Import DNSE SDK chính thức
from dnse import DNSEClient

# ==================== CẤU HÌNH ====================

BOT_TOKEN_ENC = "tokentelegram.enc"
API_KEY_ENC = "apikey.enc"
API_SECRET_ENC = "apisecret.enc"
AUTHORIZED_CHAT_ID = 7274863226  # THAY BẰNG ID CỦA BẠN

# ==================== HÀM GIẢI MÃ ====================

def decrypt_file_with_password(encrypted_file: str, password: str) -> str:
    """Giải mã file .enc bằng OpenSSL"""
    try:
        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-d", "-pbkdf2",
                "-in", encrypted_file,
                "-pass", f"pass:{password}"
            ],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        print(f"❌ Lỗi giải mã {encrypted_file}: Sai mật khẩu")
        raise
    except FileNotFoundError:
        print("❌ Lỗi: OpenSSL chưa được cài đặt")
        raise

# ==================== NHẬP MẬT KHẨU ====================

print("=" * 50)
print("🔐 DNSE TELEGRAM BOT - NHẬP MẬT KHẨU")
print("=" * 50)

try:
    password = getpass.getpass("Nhập mật khẩu để giải mã các file .enc: ")
    
    print("🔄 Đang giải mã thông tin...")
    BOT_TOKEN = decrypt_file_with_password(BOT_TOKEN_ENC, password)
    API_KEY = decrypt_file_with_password(API_KEY_ENC, password)
    API_SECRET = decrypt_file_with_password(API_SECRET_ENC, password)
    print("✅ Giải mã thành công!")
    
except Exception as e:
    print(f"❌ Lỗi giải mã: {e}")
    exit(1)

# ==================== KHỞI TẠO DNSE CLIENT ====================

client = DNSEClient(
    api_key=API_KEY,
    api_secret=API_SECRET,
    base_url="https://openapi.dnse.com.vn"
)

# ==================== LƯU TRỮ SESSION ====================

user_sessions: Dict[int, Dict[str, Any]] = {}
pending_orders: Dict[int, Dict[str, Any]] = {}

# ==================== HELPER FUNCTIONS ====================

def authorized(update: Update) -> bool:
    return update.effective_chat.id == AUTHORIZED_CHAT_ID

def safe_json_parse(data: Any) -> Dict:
    """Parse JSON an toàn"""
    if isinstance(data, dict):
        return data
    if not data:
        return {}
    if isinstance(data, str):
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            return {"error": "invalid_json", "raw": data[:200]}
    return {"error": "unknown_type"}

def format_number(value: float) -> str:
    return f"{value:,.0f}"

def get_session(user_id: int) -> Dict:
    if user_id not in user_sessions:
        user_sessions[user_id] = {}
    return user_sessions[user_id]

def is_authenticated(user_id: int) -> bool:
    session = get_session(user_id)
    return "trading_token" in session and "account_no" in session

# ==================== COMMAND HANDLERS ====================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not authorized(update):
        await update.message.reply_text("⛔ Bạn không có quyền sử dụng bot này.")
        return
    
    await update.message.reply_text(
        "🤖 **DNSE TRADING BOT**\n\n"
        "**CÁC LỆNH:**\n"
        "🔐 `/otp_smart` - Lấy mã từ app DNSE (Smart OTP)\n"
        "🔐 `/otp_email` - Nhận OTP qua email (nếu đã đăng ký)\n"
        "📋 `/info` - Thông tin tài khoản\n"
        "💰 `/balance` - Số dư tiền\n"
        "📊 `/portfolio [mã]` - Danh mục\n"
        "📒 `/orders [mã]` - Sổ lệnh\n"
        "📦 `/loan MÃ` - Gói vay\n"
        "📘 `/huongdan` - Hướng dẫn\n\n"
        "**ĐẶT LỆNH:**\n"
        "• `MUA FPT 95.5 1000`\n"
        "• `BAN HPG HET`\n"
        "• `MUA VNM MTL 1000`",
        parse_mode='Markdown'
    )

async def huongdan_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not authorized(update):
        return
    
    await update.message.reply_text(
        "📘 **HƯỚNG DẪN**\n\n"
        "**1. XÁC THỰC OTP**\n"
        "• `/otp_smart` - Dùng Smart OTP (trong app DNSE)\n"
        "• `/otp_email` - Dùng Email OTP (nếu đã đăng ký)\n"
        "• Sau đó nhập mã 6 số hoặc `/verify 123456`\n\n"
        
        "**2. TRA CỨU**\n"
        "• `/info` - Thông tin tài khoản\n"
        "• `/balance` - Số dư tiền\n"
        "• `/portfolio FPT` - Xem FPT trong danh mục\n"
        "• `/orders HPG` - Xem lệnh HPG\n"
        "• `/loan VNM` - Xem gói vay\n\n"
        
        "**3. ĐẶT LỆNH**\n"
        "• `MUA FPT 95.5 1000`\n"
        "• `BAN HPG HET`\n"
        "• `MUA VNM MTL 1000`",
        parse_mode='Markdown'
    )

async def otp_smart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lệnh /otp_smart"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    session = get_session(user_id)
    
    session["otp_type"] = "smart_otp"
    session["waiting_for_otp"] = True
    
    await update.message.reply_text(
        "🔐 **SMART OTP**\n\n"
        "1. Mở app **DNSE** trên điện thoại\n"
        "2. Vào menu → **SmartOTP**\n"
        "3. Chọn **Lấy mã cho thiết bị khác**\n"
        "4. Nhập mã 6 số vào đây\n\n"
        "⚠️ Mã có hiệu lực **30 giây**\n\n"
        "👉 Nhập trực tiếp 6 số hoặc dùng:\n"
        "   `/verify 123456`",
        parse_mode='Markdown'
    )

async def otp_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lệnh /otp_email"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    session = get_session(user_id)
    
    # Gửi email OTP theo mẫu send_email_otp.py
    try:
        status, body_text = await asyncio.to_thread(
            client.send_email_otp,
            dry_run=False
        )
        
        print(f"📧 Email OTP Status: {status}")
        print(f"📧 Email OTP Body: {body_text}")
        
        if status == 200:
            session["otp_type"] = "email_otp"
            session["waiting_for_otp"] = True
            await update.message.reply_text(
                "📧 **ĐÃ GỬI OTP QUA EMAIL**\n\n"
                "• Kiểm tra email và nhập mã 6 số\n"
                "• Mã có hiệu lực **2 phút**\n\n"
                "👉 Nhập trực tiếp 6 số hoặc dùng:\n"
                "   `/verify 123456`",
                parse_mode='Markdown'
            )
        else:
            body = safe_json_parse(body_text)
            error_msg = body.get('message', str(body_text))
            
            # Kiểm tra lỗi do chưa đăng ký email OTP
            if "EMAIL_OTP_NOT_REGISTERED" in error_msg or "chưa đăng ký" in error_msg:
                await update.message.reply_text(
                    "❌ **Tài khoản của bạn chưa đăng ký Email OTP**\n\n"
                    "Tài khoản DNSE của bạn đang dùng **Smart OTP**.\n"
                    "👉 Vui lòng dùng lệnh `/otp_smart` để lấy mã từ app DNSE.",
                    parse_mode='Markdown'
                )
            else:
                await update.message.reply_text(f"❌ Lỗi: {error_msg}")
    
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {str(e)}")

async def verify_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xác thực OTP theo mẫu create_trading_token.py"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    session = get_session(user_id)
    
    if "otp_type" not in session:
        await update.message.reply_text(
            "⚠️ Bạn cần chọn loại OTP trước:\n"
            "• `/otp_smart` - Dùng Smart OTP\n"
            "• `/otp_email` - Dùng Email OTP"
        )
        return
    
    otp_code = context.args[0] if context.args else None
    if not otp_code:
        await update.message.reply_text("Vui lòng nhập mã OTP 6 số")
        return
    
    try:
        # Gọi API tạo trading token theo mẫu
        status, body_text = await asyncio.to_thread(
            client.create_trading_token,
            otp_type=session["otp_type"],
            passcode=otp_code,
            dry_run=False
        )
        
        print(f"🔑 Verify OTP Status: {status}")
        print(f"🔑 Verify OTP Body: {body_text}")
        
        body = safe_json_parse(body_text)
        
        if status != 200 or "tradingToken" not in body:
            error_msg = body.get('message', 'Không rõ lỗi')
            
            # Xử lý lỗi sai loại OTP
            if "OTP_TYPE_INVALID" in error_msg:
                await update.message.reply_text(
                    f"❌ **SAI LOẠI OTP**\n\n"
                    f"Tài khoản của bạn đang dùng loại OTP khác.\n"
                    f"👉 Vui lòng dùng lệnh còn lại: /otp_smart hoặc /otp_email",
                    parse_mode='Markdown'
                )
                session.pop("otp_type", None)
            else:
                await update.message.reply_text(f"❌ Lỗi: {error_msg}")
            return
        
        # Lưu trading token
        trading_token = body["tradingToken"]
        session["trading_token"] = trading_token
        session.pop("waiting_for_otp", None)
        
        # Lấy thông tin tài khoản theo mẫu get_accounts.py
        acc_status, acc_body_text = await asyncio.to_thread(
            client.get_accounts,
            dry_run=False
        )
        
        if acc_status == 200:
            # Parse kết quả get_accounts
            # Kết quả mẫu: {"name": "...", "custodyCode": "...", "accounts": [...]}
            acc_data = safe_json_parse(acc_body_text)
            
            if isinstance(acc_data, dict):
                session["investor_name"] = acc_data.get("name", "Không rõ")
                session["custody_code"] = acc_data.get("custodyCode", "")
                
                accounts = acc_data.get("accounts", [])
                if accounts and len(accounts) > 0:
                    session["account_no"] = accounts[0].get("id")
        
        await update.message.reply_text(
            f"✅ **XÁC THỰC THÀNH CÔNG**\n\n"
            f"👤 **Nhà đầu tư:** {session.get('investor_name', 'N/A')}\n"
            f"💳 **TK giao dịch:** {session.get('account_no', 'N/A')}\n"
            f"🏦 **TK lưu ký:** {session.get('custody_code', 'N/A')}\n"
            f"⏱️ **Token hiệu lực:** 8 giờ",
            parse_mode='Markdown'
        )
        
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {str(e)}")

async def info_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xem thông tin tài khoản"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    if not is_authenticated(user_id):
        await update.message.reply_text("⚠️ Cần xác thực OTP trước")
        return
    
    session = get_session(user_id)
    
    await update.message.reply_text(
        f"📋 **THÔNG TIN TÀI KHOẢN**\n\n"
        f"👤 **Tên:** {session.get('investor_name', 'N/A')}\n"
        f"💳 **TK GD:** {session.get('account_no', 'N/A')}\n"
        f"🏦 **TK lưu ký:** {session.get('custody_code', 'N/A')}",
        parse_mode='Markdown'
    )

async def balance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xem số dư theo mẫu get_balances.py"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    if not is_authenticated(user_id):
        await update.message.reply_text("⚠️ Cần xác thực OTP trước")
        return
    
    session = get_session(user_id)
    
    try:
        status, body_text = await asyncio.to_thread(
            client.get_balances,
            account_no=session["account_no"],
            dry_run=False
        )
        
        if status != 200:
            await update.message.reply_text(f"❌ Lỗi: {status}")
            return
        
        data = safe_json_parse(body_text)
        
        # Tùy theo cấu trúc dữ liệu thực tế
        msg = "💰 **SỐ DƯ TÀI KHOẢN**\n\n"
        
        if isinstance(data, dict):
            # Thử với các key phổ biến
            msg += f"💵 **Tiền mặt:** {format_number(data.get('totalCash', 0))} đ\n"
            msg += f"💳 **Khả dụng:** {format_number(data.get('availableCash', 0))} đ\n"
        
        await update.message.reply_text(msg, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {str(e)}")

async def loan_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xem gói vay theo mẫu get_loan_packages.py"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    if not is_authenticated(user_id):
        await update.message.reply_text("⚠️ Cần xác thực OTP trước")
        return
    
    if not context.args:
        await update.message.reply_text("❌ /loan MÃ (vd: /loan FPT)")
        return
    
    symbol = context.args[0].upper()
    session = get_session(user_id)
    
    try:
        status, body_text = await asyncio.to_thread(
            client.get_loan_packages,
            account_no=session["account_no"],
            market_type="STOCK",
            symbol=symbol,
            dry_run=False
        )
        
        if status != 200:
            await update.message.reply_text(f"❌ Lỗi: {status}")
            return
        
        data = safe_json_parse(body_text)
        
        # Xử lý kết quả
        msg = f"📦 **GÓI VAY {symbol}**\n\n"
        
        if isinstance(data, dict):
            packages = data.get("loanPackages", [])
            if packages:
                for p in packages:
                    msg += f"**{p.get('name')}**\n"
                    msg += f"🆔 `{p.get('id')}`\n"
                    msg += "────────────────\n"
            else:
                msg += "Không có gói vay"
        
        await update.message.reply_text(msg, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {str(e)}")

async def portfolio_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xem danh mục theo mẫu get_deals.py"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    if not is_authenticated(user_id):
        await update.message.reply_text("⚠️ Cần xác thực OTP trước")
        return
    
    filter_symbol = context.args[0].upper() if context.args else None
    session = get_session(user_id)
    
    try:
        status, body_text = await asyncio.to_thread(
            client.get_deals,
            account_no=session["account_no"],
            market_type="STOCK",
            dry_run=False
        )
        
        if status != 200:
            await update.message.reply_text(f"❌ Lỗi: {status}")
            return
        
        data = safe_json_parse(body_text)
        
        msg = "📊 **DANH MỤC**\n\n"
        found = False
        
        # Xử lý theo cấu trúc thực tế
        if isinstance(data, dict):
            deals = data.get("deals", [])
            for deal in deals:
                symbol = deal.get("symbol", "").upper()
                if filter_symbol and symbol != filter_symbol:
                    continue
                
                found = True
                quantity = deal.get("openQuantity", 0)
                msg += f"**{symbol}**\n"
                msg += f"📦 {quantity:,}\n"
                msg += "────────────────\n"
        
        if not found:
            await update.message.reply_text("📊 Danh mục trống")
            return
        
        await update.message.reply_text(msg, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {str(e)}")

async def orders_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xem sổ lệnh theo mẫu get_orders.py"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    if not is_authenticated(user_id):
        await update.message.reply_text("⚠️ Cần xác thực OTP trước")
        return
    
    filter_symbol = context.args[0].upper() if context.args else None
    session = get_session(user_id)
    
    try:
        status, body_text = await asyncio.to_thread(
            client.get_orders,
            account_no=session["account_no"],
            market_type="STOCK",
            order_category="NORMAL",
            dry_run=False
        )
        
        if status != 200:
            await update.message.reply_text(f"❌ Lỗi: {status}")
            return
        
        data = safe_json_parse(body_text)
        
        msg = "📒 **SỔ LỆNH**\n\n"
        found = False
        
        if isinstance(data, dict):
            orders = data.get("orders", [])
            for order in orders[:10]:
                symbol = order.get("symbol", "").upper()
                if filter_symbol and symbol != filter_symbol:
                    continue
                
                found = True
                side = "🟢 MUA" if order.get("side") == "NB" else "🔴 BÁN"
                status_text = order.get("orderStatus", "UNKNOWN")
                
                msg += f"{side} **{symbol}**\n"
                msg += f"📊 {status_text}\n"
                msg += "────────────────\n"
        
        if not found:
            await update.message.reply_text("📒 Không có lệnh")
            return
        
        await update.message.reply_text(msg, parse_mode='Markdown')
        
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {str(e)}")

# ==================== XỬ LÝ TIN NHẮN ====================

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xử lý tin nhắn text"""
    if not authorized(update):
        return
    
    user_id = update.effective_user.id
    raw = update.message.text.strip()
    text = unidecode(raw).upper()
    
    session = get_session(user_id)
    
    # Tự động nhận OTP 6 số
    if session.get("waiting_for_otp") and raw.isdigit() and len(raw) == 6:
        context.args = [raw]
        await verify_otp(update, context)
        return
    
    # Nếu chưa xác thực
    if not is_authenticated(user_id):
        await update.message.reply_text(
            "⚠️ Bạn cần xác thực OTP trước.\n\n"
            "🔐 **Smart OTP** (dùng app DNSE): /otp_smart\n"
            "📧 **Email OTP** (nếu đã đăng ký): /otp_email\n"
            "📘 Hướng dẫn: /huongdan"
        )
        return
    
    # Xử lý lệnh mua/bán (tạm thời chưa làm)
    if text.startswith(("MUA ", "BUY ", "BAN ", "SELL ")):
        await update.message.reply_text(
            "⚠️ Tính năng đặt lệnh đang được phát triển.\n"
            "Vui lòng dùng app DNSE để giao dịch."
        )
        return
    
    await update.message.reply_text("❌ Không hiểu lệnh. Gõ /huongdan để xem hướng dẫn.")

# ==================== CHẠY BOT ====================

def main():
    print("🤖 Đang khởi động bot...")
    
    app = Application.builder().token(BOT_TOKEN).build()
    
    # Thêm handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("huongdan", huongdan_command))
    app.add_handler(CommandHandler("otp_smart", otp_smart))
    app.add_handler(CommandHandler("otp_email", otp_email))
    app.add_handler(CommandHandler("verify", verify_otp))
    app.add_handler(CommandHandler("info", info_command))
    app.add_handler(CommandHandler("balance", balance_command))
    app.add_handler(CommandHandler("loan", loan_command))
    app.add_handler(CommandHandler("portfolio", portfolio_command))
    app.add_handler(CommandHandler("orders", orders_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    print("✅ Bot đã sẵn sàng! Đang chạy...")
    app.run_polling()

if __name__ == "__main__":
    main()